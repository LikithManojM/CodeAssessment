package com.code.dao;

import java.util.List;

import com.code.entity.MycodeEntity;

public interface MycodeDAOInterface {

	int createProfileDAO(MycodeEntity w);

	boolean loginProfileDAO(MycodeEntity m);

	MycodeEntity viewprofileDAO(MycodeEntity m);

	List<MycodeEntity> searchrofileDAO(MycodeEntity m);

	int deleteProfileDAO(MycodeEntity m);

	int editProfileDAO(MycodeEntity m);

}

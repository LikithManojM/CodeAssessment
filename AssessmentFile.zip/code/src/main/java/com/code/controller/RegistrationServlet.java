package com.code.controller;

import java.io.IOException;

import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.code.entity.MycodeEntity;
import com.code.service.MycodeService;
import com.code.service.MycodeServiceInterface;


public class RegistrationServlet extends HttpServlet {
	
	           protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String name=request.getParameter("nm");
	        	String password=request.getParameter("pass");
		    String email=request.getParameter("em");
		    String address=request.getParameter("ad");
		
		MycodeEntity w=new MycodeEntity();
	 	w.setAddress(address);
		  w.setEmail(email);
		w.setPassword(password);
	w.setName(name);
		
	         MycodeServiceInterface ms=new MycodeService();
		int i=ms.createProfileService(w);
		
		      if(i>0) {
			request.setAttribute("result", "Profile created <a href=login.jsp>Sign In</a>");
		  	
			     RequestDispatcher rd=getServletContext().getRequestDispatcher("/register.jsp");
			rd.forward(request, response);
		}
		 else {
			   request.setAttribute("result","could not create profile");
			   RequestDispatcher rd=getServletContext().getRequestDispatcher("/register.jsp");
			   rd.forward(request, response);
		}
		
		

	}

}

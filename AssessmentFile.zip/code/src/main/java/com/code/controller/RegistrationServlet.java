package com.code.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.code.entity.MycodeEntity;
import com.code.service.MycodeService;
import com.code.service.MycodeServiceInterface;


public class RegistrationServlet extends HttpServlet {
	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String name=request.getParameter("nm");
		  String password =request.getParameter("ps");
		String email=request.getParameter("em");
		  String address=request.getParameter("ad");
		
		      MycodeEntity m=new MycodeEntity();
		      m.setName(name);
		      m.setPassword(password);
		   m.setEmail(email);
		      m.setAddress(address);
		
		MycodeServiceInterface ms=new MycodeService();
		  int i=ms.createProfileService(m);
		
		  response.setContentType("text/html");
		  PrintWriter out=response.getWriter();
		
		 out.println("<html><body><center>");
			if(i>0) {
				
//				out.println("Profile created <a href=login.html>Sign In</a>");
			}
			else {
			out.println("could not create profile");
			}
			out.println("</center></body></html>");
			}
		

}

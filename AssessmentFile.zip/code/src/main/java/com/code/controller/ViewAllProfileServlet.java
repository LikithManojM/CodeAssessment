package com.code.controller;



import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;



import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;



import com.code.entity.MycodeEntity;
import com.code.service.MycodeService;
import com.code.service.MycodeServiceInterface;




public class ViewAllProfileServlet extends HttpServlet {

protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
HttpSession s=request.getSession(true);
Object oo=s.getAttribute("id");
String email=oo.toString();

MycodeEntity m=new MycodeEntity();
m.setEmail(email);

MycodeServiceInterface ms=new MycodeService();
List<MycodeEntity> mm=ms.viewallprofile(m);

response.setContentType("text/html");
PrintWriter out=response.getWriter();

out.println("<html><body><center>");
for(MycodeEntity mm1:mm) {
out.println("Name is "+mm1.getName());
out.println("<br>Password is "+mm1.getPassword());
out.println("<br>Email is "+mm1.getEmail());
out.println("<br>Address is "+mm1.getAddress());
}

out.println("</center></body></html>");
}



}
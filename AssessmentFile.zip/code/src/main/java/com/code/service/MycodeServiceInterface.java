package com.code.service;



import com.code.entity.MycodeEntity;

public interface MycodeServiceInterface {

	  int createProfileService(MycodeEntity w);

	 boolean loginProfile(MycodeEntity m);

	MycodeEntity viewprofile(MycodeEntity m);

	

	int deleteprofile(MycodeEntity m);

	

}

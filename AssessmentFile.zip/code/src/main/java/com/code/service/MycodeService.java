package com.code.service;

import java.util.List;


import com.code.dao.MycodeDAO;
import com.code.dao.MycodeDAOInterface;

import com.code.entity.MycodeEntity;

public class MycodeService implements MycodeServiceInterface {

	//@Override
	    public int createProfileService(MycodeEntity w) {
		  MycodeDAOInterface md=new MycodeDAO();
		
		      return md.createProfileDAO(w);
	}

	//@Override
	     public boolean loginProfile(MycodeEntity m) {
		   MycodeDAOInterface md=new MycodeDAO();
		  return md.loginProfileDAO(m);
	}

	//@Override
	   public MycodeEntity viewprofile(MycodeEntity m) {
		  MycodeDAOInterface md=new MycodeDAO();
		  return md.viewprofileDAO(m);
	}



	//@Override
	   public int deleteprofile(MycodeEntity m) {
		   MycodeDAOInterface md=new MycodeDAO();
		   return md.deleteProfileDAO(m);
	}
	   
	   public List<MycodeEntity> viewallprofile(MycodeEntity m) {
		   MycodeDAOInterface md=new MycodeDAO();
		   return md.viewallprofileDAO(m);
		   }
	   
}


